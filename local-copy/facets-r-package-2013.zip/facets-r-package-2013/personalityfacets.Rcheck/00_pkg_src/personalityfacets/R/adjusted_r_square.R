#' @title Calculate adjusted r square
#' 
#' @description Calculates adjusted r square 
#' 
#' @param rsquared value of r-squared from a regression model
#' @param n sample size
#' @param p number of predictors
#' @param method for calculating r-squared (currently takes 'ezekiel' or 'olkinpratt')
#' @return adjusted r-square
#' @export
#' @examples
#' data(facets_data); data(facets_meta)
#' rs <- summary(regression('swl', ivs=facets_meta$ipip_factors, data=facets_data))$r.squared
#' n <- nrow(facets_data)
#' p <- length(facets_meta$ipip_factors)
#' adjusted_r_squared(rs, n, p, method='ezekiel')
#' adjusted_r_squared(rs, n, p, method='olkinpratt')
adjusted_r_squared <- function(rsquared, n, p, method='ezekiel') {
    if (method=='ezekiel') {
        return( 
            1 - (1-rsquared)  * ((n-1)/(n-p-1))
        )
    }
    if (method=='olkinpratt') {
        return(
        1 - ((n-3)/(n-p-1)) * (1-rsquared) * phyper(1, 1, (n-p + 1)/2, 1-rsquared)
        )
    }
    
    if (method=='pratt') {
        part1 <- ((n - 3) * (1- rsq)) / (n - p - 1)
        part2 <- 1 + (2 * (1 - rsq))/ (n - p - 2.3)
        1 - part1 * part2
    }
}

#' @title Calculate adjusted r square
#' 
#' @description Calculates adjusted r square 
#' 
#' @param fit object of class lm
#' @param method for calculating r-squared (currently takes 'ezekiel' or 'olkinpratt')
#' @return adjusted r-square
#' @export
#' @examples
#' data(facets_data); data(facets_meta)
#' fit <- regression('swl', ivs= facets_meta$ipip_factors, data=facets_data)
#' lm_adjusted_r_squared(fit, method='olkinpratt')
lm_adjusted_r_squared <- function(fit, method) {
    rsquared <- summary(fit)$r.squared
    n <- length(fit$residuals)
    # minus 1 to remove the intercept
    p <- length(fit$coefficients) - 1 
    adjusted_r_squared(rsquared=rsquared, n=n, p=p, method=method)
}   


