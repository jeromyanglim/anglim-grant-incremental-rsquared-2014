pkgname <- "personalityfacets"
source(file.path(R.home("share"), "R", "examples-header.R"))
options(warn = 1)
library('personalityfacets')

base::assign(".oldSearch", base::search(), pos = 'CheckExEnv')
cleanEx()
nameEx("adjusted_r_square")
### * adjusted_r_square

flush(stderr()); flush(stdout())

### Name: adjusted_r_square
### Title: Calculate adjusted r square
### Aliases: adjusted_r_square

### ** Examples

rs <- summary(regression('swl', ivs=facets_meta$ipip_factors, data=facets_data))$r.squared
n <- nrow(facets_data)
p <- length(facets_meta$ipip_factors)
adjusted_r_square(rs, n, p, method='ezekiel')
adjusted_r_square(rs, n, p, method='olkinpratt')



cleanEx()
nameEx("adjusted_r_squared")
### * adjusted_r_squared

flush(stderr()); flush(stdout())

### Name: adjusted_r_squared
### Title: Calculate adjusted r square
### Aliases: adjusted_r_squared

### ** Examples

data(facets_data); data(facets_meta)
rs <- summary(regression('swl', ivs=facets_meta$ipip_factors, data=facets_data))$r.squared
n <- nrow(facets_data)
p <- length(facets_meta$ipip_factors)
adjusted_r_squared(rs, n, p, method='ezekiel')
adjusted_r_squared(rs, n, p, method='olkinpratt')



cleanEx()
nameEx("bootstrap_r_square_change")
### * bootstrap_r_square_change

flush(stderr()); flush(stdout())

### Name: bootstrap_r_square_change
### Title: Bootstrap estimate of popualtion r-square of difference between
###   facets and factors
### Aliases: bootstrap_r_square_change

### ** Examples

bootstrap_r_square_change(facets_data, facets_meta$swb[1], facets_meta$ipip_factors, facets_meta$ipip_facets)



cleanEx()
nameEx("bootstrap_r_squared_change")
### * bootstrap_r_squared_change

flush(stderr()); flush(stdout())

### Name: bootstrap_r_squared_change
### Title: Bootstrap estimate of popualtion r-square of difference between
###   facets and factors
### Aliases: bootstrap_r_squared_change

### ** Examples

data(facets_data); data(facets_meta)
bootstrap_r_squared_change(facets_data, facets_meta$swb[1], facets_meta$ipip_factors, facets_meta$ipip_facets)



cleanEx()
nameEx("lm_adjusted_r_square")
### * lm_adjusted_r_square

flush(stderr()); flush(stdout())

### Name: lm_adjusted_r_square
### Title: Calculate adjusted r square
### Aliases: lm_adjusted_r_square

### ** Examples

fit <- regression('swl', ivs= facets_meta$ipip_factors, data=facets_data)
lm_adjusted_r_square(fit, method='olkinpratt')



cleanEx()
nameEx("lm_adjusted_r_squared")
### * lm_adjusted_r_squared

flush(stderr()); flush(stdout())

### Name: lm_adjusted_r_squared
### Title: Calculate adjusted r square
### Aliases: lm_adjusted_r_squared

### ** Examples

data(facets_data); data(facets_meta)
fit <- regression('swl', ivs= facets_meta$ipip_factors, data=facets_data)
lm_adjusted_r_squared(fit, method='olkinpratt')



cleanEx()
nameEx("regression")
### * regression

flush(stderr()); flush(stdout())

### Name: regression
### Title: lm regression using character strings
### Aliases: regression

### ** Examples

data(facets_data); data(facets_meta)
regression(facets_meta$swb[1], facets_meta$ipip_factors, facets_data)



### * <FOOTER>
###
options(digits = 7L)
base::cat("Time elapsed: ", proc.time() - base::get("ptime", pos = 'CheckExEnv'),"\n")
grDevices::dev.off()
###
### Local variables: ***
### mode: outline-minor ***
### outline-regexp: "\\(> \\)?### [*]+" ***
### End: ***
quit('no')
