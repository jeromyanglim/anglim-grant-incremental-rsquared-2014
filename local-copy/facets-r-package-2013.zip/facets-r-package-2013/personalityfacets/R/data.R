#' Data file with personality facets, personality factors, and well being outcomes
#'
#' @name facets_data 
#' @docType data
#' @keywords data
NULL

#' Meta Data for facets_data
#'
#' @name facets_meta
#' @docType data
#' @keywords data
NULL